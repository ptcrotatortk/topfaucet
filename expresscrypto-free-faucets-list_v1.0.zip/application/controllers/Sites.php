<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sites extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('parser');
        $this->load->helper('url');
        $this->api_key = $this->config->item('api_key');
        $this->user_token = $this->config->item('user_token');
        $this->cache_time = $this->config->item('cache_time');
        $this->ref_wallets = $this->config->item('ref_wallets');
        $this->new_urls = $this->config->item('new_urls');

    }






public function index($coin ="BTC")
	{
 
 $this->fcoin = strtoupper($coin);
 

        $_file  = 'application/cache/sites_list_express.json';
        $_cache = @file_get_contents($_file);
         $last_update ="NOW";
        if ($_cache === false) {
            $_list = $this->getList();

        } else {
            $file_time = filemtime($_file);
             $last_update ="on ".date('d M Y H:i',$file_time);
        if (time() - $file_time > $this->cache_time) { $_list = $this->getList();  }
            $_list = json_decode($_cache, true);
        }
 

$coins = array_map(function ($v) {
    return ['currency' => $v];
},array_unique(array_column($_list['sites'], 'currency')));
 $coinsdb = [];
    foreach ( $coins as $key => $value) {
      $nav_active = ($value['currency'] == $this->fcoin) ? 'active' : '' ;
     array_push($coinsdb,['nav_active' => $nav_active, 'coin'=> $value['currency'], 'url'=> base_url('sites/'.$value['currency'])]);
    }

 
$currency_sites = array_filter($_list['sites'], function($arg) { return ($arg['currency'] == $this->fcoin); });
 
  
$_sites=[];
    foreach ($currency_sites as $key => $value) {
 
 
       $_sites[$key]['id']=$key;
       $_sites[$key]['new'] = 0;
       $_sites[$key]['new_html'] = '';
       if (strtotime($value['activeSince'])>time()-3600*24*$this->config->item('new_days')) { $_sites[$key]['new']=1;  $_sites[$key]['new_html'] = '<span class="badge badge-success">New</span>';}
 
        $_sites[$key]['timer']=round($value['timeFrame']/60);
        $_sites[$key]['reward']=$value['reward'];
        $_sites[$key]['totalPaid']=$value['totalPaid'];
 
        $_sites[$key]['name']=$value['siteName'];

        if ($value['abilityToPay'] == 'Good') { $_sites[$key]['abilityToPay'] = '<span class="badge badge-success">Good</span>'; } 
          else if ($value['abilityToPay'] == 'Critical') { $_sites[$key]['abilityToPay'] = '<span class="badge badge-warning">Critical</span>'; } 
          else if ($value['abilityToPay'] == 'Empty') {  $_sites[$key]['abilityToPay'] = '<span class="badge badge-danger">Empty</span>';} 
          else { $_sites[$key]['abilityToPay'] = '<span class="badge badge-info">Unknown</span>';  } 


 
        $_sites[$key]['activeSince']=$value['activeSince'];
        $_sites[$key]['users']=$value['users'];
        $_sites[$key]['url']=$this->changeUrl($key,$value['currency'],$value['link']);
 
    }


 
usort($_sites, function($a, $b) { return $a['activeSince'] < $b['activeSince']; });


 

 $data = array(
 		'list_name' => $this->config->item('list_name'),
 		'base_url' => base_url(),
        'page_title' => 'Top '.$this->fcoin.' Faucet Sites',
        'coin' => $this->fcoin,
        'sites' => $_sites,
        'coins' => $coinsdb,
        'last_update' => $last_update,
);
 
$this->parser->parse('sites', $data);
 
	}



   private function getList()
    {

 

        $_file  = 'application/cache/sites_list_express.json';
        $params = array("api_key" => $this->api_key,"user_token"=>$this->user_token,"ip_user"=>"");
 	   $ch     = curl_init('https://expresscrypto.io/public-api/v2/getListOfSites');
 

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response_ch = curl_exec($ch);
        curl_close($ch);
         $_list    = json_decode($response_ch, true);
          if ($_list['status'] == 200) {
                @file_put_contents($_file, $response_ch);
            }
     return $_list;
 
 

    }
private function findSite($sites, $url) {
	  $to_check=  array_keys($sites);
	 
    foreach ( $to_check as $a ) { if ( stripos ( $url , $a ) !== FALSE ) { return $sites[$a]; } }
    return false;
} 

private function changeUrl($id,$coin,$url){
  $coin = strtoupper($coin);
  $site_found = $this->findSite($this->new_urls,$url);
if ($site_found) {$url=$site_found;}
 else{ $url = (isset($this->ref_wallets[$coin])) ?  $url.'?r='.$this->ref_wallets[$coin] : $url ;}
 
return $url;
}






}
