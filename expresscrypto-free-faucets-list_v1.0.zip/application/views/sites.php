<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <title>{page_title}</title>
 
    <!-- Bootstrap core CSS -->
<link href="{base_url}assets/bootstrap/bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      body {
  padding-top: 5rem;
}
.starter-template {
  padding: 3rem 1.5rem;
  text-align: center;
}

 
.list-footer {
  padding: 1.5rem 0;
  color: #999;
  text-align: center;
  background-color: #f9f9f9;
  border-top: .05rem solid #e5e5e5;
}
.list-footer p:last-child {
  margin-bottom: 0;
}
    </style>
 
  </head>
  <body>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
  <a class="navbar-brand" href="#">{list_name}</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarsExampleDefault">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
 
    </ul>
 
  </div>
</nav>

<main role="main" class="container">

 

 
  <div class="starter-template">
    <h1>ExpressCrypto.io Top {coin} Faucet Sites</h1>
    <p class="lead">Claim from a number of free cryptocurrency faucets</p>
 



<nav class="nav nav-pills justify-content-center">
{coins}
<a href="{url}" class="flex-sm-fill nav-link {nav_active}" >{coin}</a>
{/coins} 
</nav>
 </div>


 <table id="fgsDataTable1" class="table">
  <thead>
    <tr>
    
      <th scope="col">Name</th>
      <th scope="col" data-sortable="false"></th>
      
      <th scope="col">Ability to Pay</th>
      <th scope="col">Users</th>
      <th scope="col">Reward</th>
 
      <th scope="col">Timer</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
{sites} 

    <tr>
      <td>{name}</td>
      <td>{new_html}</td>
      <td>{abilityToPay} </td>
      <td>{users} </td>
      <td>{reward} </td>
 
       <td>{timer}</td>
      <td><button class="btn btn-secondary my-2 my-sm-0" onclick="window.open('{url}')">Visit</button></td>
    </tr>

 

 {/sites}

 
  </tbody>
</table>
 
</main><!-- /.container -->

<footer class="list-footer">
  <p>Update : {last_update} | {memory_usage}  | Get Free <a href="https://faucetgamescript.com/scripts/free-faucets-list">Faucets List Script</a> by <a href="https://faucetgamescript.com">FGS</a> . <a href="#">top^</a></p>
</footer>


  <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">


    $('#fgsDataTable1').DataTable(     {
      "order": [[ 1, "desc" ],[3,"desc"]],
      "pageLength": 25,
      
    })

</script>




<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script>window.jQuery || document.write('<script src="{base_url}assets/bootstrap/bootstrap-4.3.1/js/vendor/jquery-slim.min.js"><\/script>')</script><script src="{base_url}assets/bootstrap/bootstrap-4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script></body>
</html>
